<div align="center">

# 🤖 Agent Interview Hub

**国内最全的 AI Agent 工程师面试知识库**

[![Stars](https://img.shields.io/github/stars/Zchary1106/agent-interview-hub?style=flat-square&logo=github)](https://github.com/Zchary1106/agent-interview-hub/stargazers)
[![Forks](https://img.shields.io/github/forks/Zchary1106/agent-interview-hub?style=flat-square&logo=github)](https://github.com/Zchary1106/agent-interview-hub/network/members)
[![License](https://img.shields.io/github/license/Zchary1106/agent-interview-hub?style=flat-square)](LICENSE)
[![Last Commit](https://img.shields.io/github/last-commit/Zchary1106/agent-interview-hub?style=flat-square)](https://github.com/Zchary1106/agent-interview-hub/commits/main)

**300+ 面试题与参考答案 · 15 类公司/岗位资料（含 Anthropic 等海外顶级 AI 公司）· 6 道实操考题 · 16 周完整学习路线图**

[📖 经典版](https://zchary1106.github.io/agent-interview-hub/index.html) · [✨ 新版](https://zchary1106.github.io/agent-interview-hub/new.html) · [🔥 高频题信号榜](https://zchary1106.github.io/agent-interview-hub/question-signals.html) · [⭐ Star 支持](https://github.com/Zchary1106/agent-interview-hub) · [🐛 提交面经](https://github.com/Zchary1106/agent-interview-hub/issues)

</div>

---

## 📌 这是什么？

专为**国内大厂 AI Agent 工程师**跳槽/求职打造的一站式面试知识库。

- 🎯 **面向谁** — 准备跳槽阿里、字节、腾讯、百度等大厂 Agent 岗位的工程师
- 📚 **包含什么** — 300+ 高频问题与参考答案、15 类公司/岗位资料、6 道限时实操考题、35 篇通用知识文档
- 🗺️ **学习路线** — 从零到 Offer 的 16 周完整学习计划
- ✨ **特色亮点** — 题目全带答案、面经来自牛客真实分享、支持 GitHub Pages 在线浏览

---

## 🧭 知识体系

```
AI Agent 工程师知识体系
│
├── 🧱 基础层
│   ├── Transformer 架构与注意力机制
│   ├── LLM 原理 / Tokenization / Embedding
│   └── Prompt Engineering 基础
│
├── 🔧 核心层
│   ├── Agent 设计模式（ReAct / Plan-and-Execute / Multi-Agent）
│   ├── RAG 全链路（检索 / 分块 / 重排 / 生成）
│   ├── Function Calling / Tool Use 🆕
│   ├── MCP（Model Context Protocol）🆕
│   ├── 主流框架（LangChain / LangGraph / AutoGen）
│   └── Context Engineering 上下文工程
│
├── 🚀 进阶层
│   ├── Agentic RAG / GraphRAG
│   ├── Agentic Coding 与 AI 编程工具 🆕
│   ├── 模型微调 / 推理优化 / 量化部署
│   └── Agent 安全、评估与对齐
│
└── 💼 实战层
    ├── 系统设计与项目经验
    ├── 大厂岗位要求解读
    └── 面试技巧与真实面经
```

---

## 🗺️ 学习路线图

> 16 周从基础到 Offer，每周有明确目标和推荐资料

➡️ [**Agent工程师学习路线图.md**](Agent工程师学习路线图.md)

---

## 📚 通用知识

### 🆕 2026 年 10 月主题练习与参考答案

[**156 道题分类索引**](通用知识/2026-10-Agent面试题索引.md) · [来源分级与答案资料](通用知识/2026-10-Agent面经来源与答案资料.md)

覆盖 13 类：127 道通用技术题放入 `通用知识/`、15 道算法题及 Python 实现放入 `面试算法题/`、14 道项目题放入 `项目实战/`。每题附参考答案、得分点、追问与易错点，并接入新版交互题库的「2026-10 跨公司主题练习（非真题）」分组。

> 来源快照为 **2026-10-22**，答案整理于 **2026-10-23**。题目按公开面经报道主题改写，**不是公司官方真题或标准答案**；63 条来源保留 B/C 证据状态，不将聚合线索、付费预览或编辑改写升级成真实面试。答案未经独立专家逐题复核，详见索引边界说明。

### 🔧 核心技术

| # | 文档 | 简介 |
|---|------|------|
| 1 | [12 周 Agent 工程师进阶路线](通用知识/12周Agent工程师进阶路线.md) | 以周为单位交付 RAG、Agent、MCP、生产化作品集 |
| 2 | [Agent 核心概念与设计模式](通用知识/Agent核心概念与设计模式.md) | ReAct、Plan-and-Execute、Multi-Agent 等核心范式 |
| 3 | [Agent 框架全景](通用知识/Agent框架全景.md) | LangChain、AutoGen、CrewAI 等主流框架横评 |
| 4 | [LangChain 与 LangGraph 深度解析](通用知识/LangChain与LangGraph深度解析.md) | 链式调用到图编排的演进与实战 |
| 5 | [RAG 核心知识与面试题](通用知识/RAG核心知识与面试题.md) | 检索增强生成全链路：分块、检索、重排、生成 |
| 6 | [Agentic RAG 与 GraphRAG 深度解析](通用知识/Agentic%20RAG与GraphRAG深度解析.md) | 从朴素 RAG 到 Agent 驱动的智能检索 |
| 7 | [Context Engineering 上下文工程](通用知识/Context%20Engineering上下文工程.md) | 上下文窗口管理、压缩与优化策略（含 Anthropic 最新实践）🔄 |
| 8 | [Agent 安全与评估体系](通用知识/Agent安全与评估体系.md) | Prompt 注入防御、幻觉检测、评估框架 |
| 9 | [大模型推理优化与部署](通用知识/大模型推理优化与部署.md) | 量化、蒸馏、KV Cache、vLLM 等推理加速 |
| 10 | [Function Calling 与 Tool Use 专题](通用知识/Function%20Calling与Tool%20Use专题.md) | 三大厂商实现对比、调用模式、安全防御 🆕 |
| 11 | [MCP 与工具生态](通用知识/MCP与工具生态.md) | Model Context Protocol 架构、开发实战、企业应用 🆕 |
| 12 | [Agentic Coding 与 AI 编程工具](通用知识/Agentic%20Coding与AI编程工具.md) | Claude Code / Cursor / Copilot 对比、Hooks、人机协作 🆕 |
| 13 | [Agent Harness 与编码代理测评](通用知识/Agent%20Harness与编码代理测评.md) | Codex CLI / Claude Code / OpenHands 等 Harness 深度测评与源码入口 🆕 |
| 14 | [2026 Agent 工程化新考点](通用知识/2026-Agent工程化新考点.md) | Runtime、可恢复执行、路径震荡、工具路由、Trace 与生产级评测 🆕 |
| 15 | [Agent Harness 评测与发布门禁](通用知识/Agent-Harness评测与发布门禁.md) | Task/Environment/Outcome Spec、三层 Grading、Shadow 与 Canary |
| 16 | [企业级 Agent 平台与 AgentOS](通用知识/企业级Agent平台与AgentOS.md) | 控制面、Runtime、多租户、Registry、模型网关与平台治理 |
| 17 | [自进化 Agent 与 Skill 生命周期](通用知识/自进化Agent与Skill生命周期.md) | Trace 复盘、Curator、Skill 版本、灰度、回滚与防污染 |

### 📝 面试题库

| # | 文档 | 简介 |
|---|------|------|
| 18 | [最新 AI Agent 面经索引（2026）](通用知识/最新AI-Agent面经索引.md) | 牛客、小红书、知乎、CSDN、GitHub 等公开来源的最新面经入口 |
| 19 | [Agent 高频题证据模型](通用知识/Agent高频题证据模型.md) | 公司、轮次、来源数、时效、一手/汇总与置信度 |
| 20 | [跨公司 Agent 岗位能力矩阵](通用知识/跨公司Agent岗位能力矩阵.md) | 应用、算法、Runtime、Coding Agent 和平台岗位对比 |
| 21 | [Agent 项目深挖与压力面试](通用知识/Agent项目深挖与压力面试.md) | 九组连续追问链、回答证据和评分标准 |
| 22 | [Agent 项目简历与 STAR 表达](通用知识/Agent项目简历与STAR表达.md) | 1/3 分钟表达、技术难点、失败案例和指标写法 |
| 23 | [核心概念详解与参考答案](通用知识/核心概念详解与参考答案.md) | 高频概念题精讲与标准答案 |
| 24 | [八股文完整答案集](通用知识/八股文完整答案集.md) | 69 道八股题，全部附详细解答 |
| 25 | [八股文题库 - DataWhale 开源](通用知识/八股文题库-DataWhale开源.md) | DataWhale 社区精选题库 |
| 26 | [高频拷打题 - 牛客热帖](通用知识/高频拷打题-牛客热帖.md) | 牛客论坛高赞面试拷打合集 |
| 27 | [技术知识点汇总](通用知识/技术知识点汇总.md) | 速查手册：关键知识点一网打尽 |
| 28 | [其他公司面经 - 快手携程等](通用知识/其他公司面经-快手携程等.md) | 快手、携程等公司面经补充 |

### 🌐 进阶面试题

| # | 文档 | 简介 |
|---|------|------|
| 29 | [Agent 核心概念面试题 - 进阶篇](通用知识/Agent核心概念面试题-进阶篇.md) | 核心概念高频问答进阶版 |
| 30 | [系统设计面试题 - 进阶篇](通用知识/系统设计面试题-进阶篇.md) | 系统设计题与参考答案进阶版 |
| 31 | [AI 协作与工程化面试题 - 进阶篇](通用知识/AI协作与工程化面试题-进阶篇.md) | AI 协作工程化问答进阶版 |
| 32 | [AI 模型与 Agent 手撕题](面试算法题/AI模型与Agent手撕题.md) | Attention、LoRA、检索、RRF、Tool 校验与 Agent Loop |
| 33 | [交互式面试算法题图谱](https://zchary1106.github.io/agent-interview-hub/%E9%9D%A2%E8%AF%95%E7%AE%97%E6%B3%95%E9%A2%98/) | 近期公开 Agent / 大模型面经算法题，附可折叠 Java 解法 |

---

## 🎯 实操考题（限时挑战）

> 来自 [agent-interview-prep](https://github.com/Zchary1106/agent-interview-prep) 项目，模拟真实面试场景的限时编程题

> 🗺️ 使用 Obsidian 的同学可以打开 [Agent 工程师知识地图](Agent工程师知识地图.canvas)，从长期路线、核心知识、项目实战和公司面经四条线复习。

| # | 题目 | 难度 | 限时 |
|---|------|:----:|:----:|
| 1 | [智能文档问答 Agent](项目实战/实操考题/01-智能文档问答Agent.md) | ⭐⭐ | 4-6h |
| 2 | [多 Agent 团队协作](项目实战/实操考题/02-多Agent团队协作.md) | ⭐⭐ | 4-6h |
| 3 | [ReAct 模式 Agent](项目实战/实操考题/03-ReAct模式Agent.md) | ⭐⭐ | 3-5h |
| 4 | [AI 限时全栈开发](项目实战/实操考题/04-AI限时全栈开发.md) | ⭐⭐ | 2-3h |
| 5 | [AI 调试挑战](项目实战/实操考题/05-AI调试挑战.md) | ⭐⭐⭐ | 1-2h |
| 6 | [AI Code Review Agent](项目实战/实操考题/06-AI-CodeReview-Agent.md) | ⭐⭐⭐ | 4-6h |

---

## 🏢 国内大厂面经

| 公司 | 岗位要求 | 面试题 | 真实面经 |
|------|:--------:|:------:|:--------:|
| [阿里巴巴](阿里巴巴/) | ✅ | ✅ | ✅ |
| [字节跳动](字节跳动/) | ✅ | ✅ | ✅ |
| [小红书](小红书/) | ✅ | ✅ | ✅ |
| [百度](百度/) | ✅ | ✅ | — |
| [腾讯](腾讯/) | ✅ | ✅ | — |
| [美团](美团/) | ✅ | ✅ | ✅ |
| [蚂蚁集团](蚂蚁集团/) | ✅ | ✅ | ✅ |
| [华为](华为/) | ✅ | ✅ | ✅ |
| [快手](快手/) | ✅ | ✅ | ✅ |

## 🌍 海外顶级 AI 公司面经

| 公司 | 岗位要求 | 面试题 | 真实面经 |
|------|:--------:|:------:|:--------:|
| [OpenAI](OpenAI/) | ✅ | ✅ | ✅ |
| [Anthropic](Anthropic/) 🆕 | ✅ | ✅ | ✅ |
| [谷歌 (Google DeepMind)](谷歌/) | ✅ | ✅ | — |
| [微软 (Microsoft)](微软/) | ✅ | ✅ | — |
| [初创公司](初创公司/) | ✅ | ✅ | — |

> 📖 海外公司综合攻略：[海外顶级AI公司面试攻略-2026](通用知识/海外顶级AI公司面试攻略-2026.md) 🆕

---

## 🚀 使用指南

### 在线阅读（推荐）

访问 GitHub Pages 站点，移动端友好：

- **经典版（原页面）**：https://zchary1106.github.io/agent-interview-hub/index.html
- **新版（备考路径版）**：https://zchary1106.github.io/agent-interview-hub/new.html
- **高频题信号榜**：https://zchary1106.github.io/agent-interview-hub/question-signals.html

经典版保持原有内容和默认地址，并在页面顶部提示切换新版；新版使用新的求职准备布局。

### 本地阅读

```bash
git clone https://github.com/Zchary1106/agent-interview-hub.git
cd agent-interview-hub
# 用任意 Markdown 编辑器打开即可
```

### 本地构建静态站

```bash
python3 -m pip install -r requirements.txt
python3 scripts/build_site.py
python3 -m http.server 8000 -d dist
```

生成结果会输出到 `dist/`。GitHub Pages 通过 `.github/workflows/pages.yml` 在 `main` 分支 push 后自动构建并发布。

### 安装面经采集 Agent

本仓库内置 Interview Collector Agent，用于从牛客、小红书、知乎、CSDN、博客园、掘金、GitHub 等公开来源搜索面经，整理成结构化候选，再同步到索引和公司文档。

```bash
bash agents/interview-collector/install.sh --targets copilot,claude,cursor,generic
```

支持安装到：

| 平台 | 写入位置 |
|---|---|
| GitHub Copilot CLI | `~/.copilot/instructions/interview-collector.instructions.md` |
| Claude Code | `~/.claude/skills/interview-collector/SKILL.md` |
| Cursor | `.cursor/rules/interview-collector.mdc` |
| 通用/国内 Agent | `~/.agent-interview-hub/interview-collector/AGENT.md` |

详见 [Interview Collector Agent 说明](agents/interview-collector/README.md)。

完整采集流程也可以用脚本跑：

```bash
# 1. 检查本机搜索/读取工具
python3 scripts/collect_interviews.py doctor

# 2. 搜索公开来源，生成候选 JSON 和 Markdown 报告
python3 scripts/collect_interviews.py search \
  --platform nowcoder \
  --platform zhihu \
  --platform blogs \
  --platform github \
  --query "AI Agent 大模型 面经 2026" \
  --output data/interview_candidates.json \
  --report data/interview_candidates.md

# 3. 人工或 Agent 审核候选后，再整理进 data/interviews.json
python3 -m json.tool data/interviews.json
python3 scripts/build_site.py
```

如果本机已配置 OpenCLI，也可以追加小红书搜索：

```bash
python3 scripts/collect_interviews.py search \
  --platform xiaohongshu \
  --query "AI Agent 面经" \
  --append
```

### 推荐阅读顺序

1. 📖 先看 [学习路线图](Agent工程师学习路线图.md)，了解全局
2. 🧱 通读 [Agent 核心概念与设计模式](通用知识/Agent核心概念与设计模式.md)
3. 🔧 深入 [RAG](通用知识/RAG核心知识与面试题.md) 和 [LangChain/LangGraph](通用知识/LangChain与LangGraph深度解析.md)
4. 🆕 掌握 [Function Calling](通用知识/Function%20Calling与Tool%20Use专题.md) 和 [MCP](通用知识/MCP与工具生态.md)（2025 高频新考点）
5. 📝 刷 [八股文完整答案集](通用知识/八股文完整答案集.md)（69 题）
6. 🏢 针对目标公司看对应面经
7. 🔥 最后用 [高频拷打题](通用知识/高频拷打题-牛客热帖.md) 查漏补缺

---

## 🤝 贡献指南

欢迎一切形式的贡献！

- **📝 提交面经** — 通过 [Issue](https://github.com/Zchary1106/agent-interview-hub/issues) 分享你的面试经历
- **🔧 提交 PR** — 补充题目、修正答案、新增公司面经
- **⭐ Star** — 最简单的支持方式，让更多人看到

### 贡献步骤

```bash
# 1. Fork 本仓库
# 2. 创建分支
git checkout -b feat/add-xxx-interview
# 3. 提交更改
git commit -m "feat: 新增 xxx 面经"
# 4. 推送并创建 PR
git push origin feat/add-xxx-interview
```

---

## Star History

<a href="https://www.star-history.com/?repos=Zchary1106%2Fagent-interview-hub&type=date&legend=top-left">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=Zchary1106/agent-interview-hub&type=date&theme=dark&legend=top-left&sealed_token=DfBi-7mZKgMVl-BeniZrCE4YK80OxR9fwmi1922GzQnfZOHWGOe2DUGMzE8YxITxnzk0TVDUg-3VYolGAmqeUToB3b2qPRJtGfyxc36h8oOzxCImLmYPQQQ6HQEdA7KfyzP7blHww6t0vmBDWyk-GsQf3rLTW5nRIy6Dqw7Y86eqv_xvqS4N4dlOOPFZ" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=Zchary1106/agent-interview-hub&type=date&legend=top-left&sealed_token=DfBi-7mZKgMVl-BeniZrCE4YK80OxR9fwmi1922GzQnfZOHWGOe2DUGMzE8YxITxnzk0TVDUg-3VYolGAmqeUToB3b2qPRJtGfyxc36h8oOzxCImLmYPQQQ6HQEdA7KfyzP7blHww6t0vmBDWyk-GsQf3rLTW5nRIy6Dqw7Y86eqv_xvqS4N4dlOOPFZ" />
   <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=Zchary1106/agent-interview-hub&type=date&legend=top-left&sealed_token=DfBi-7mZKgMVl-BeniZrCE4YK80OxR9fwmi1922GzQnfZOHWGOe2DUGMzE8YxITxnzk0TVDUg-3VYolGAmqeUToB3b2qPRJtGfyxc36h8oOzxCImLmYPQQQ6HQEdA7KfyzP7blHww6t0vmBDWyk-GsQf3rLTW5nRIy6Dqw7Y86eqv_xvqS4N4dlOOPFZ" />
 </picture>
</a>

---

## 📄 License

本项目采用 [MIT License](LICENSE) 开源。

---

<div align="center">

**如果这个项目对你有帮助，请给一个 ⭐ Star 支持！**

Made with ❤️ for AI Agent Engineers

</div>
